from flask import Flask, jsonify
import time
import logging
from datetime import datetime
from prometheus_client import generate_latest, Counter, Histogram, REGISTRY

# JSON structured logging
logging.basicConfig(
    level=logging.INFO,
    format='{"time": "%(asctime)s", "level": "%(levelname)s", "service": "backend", "message": "%(message)s"}',
    datefmt='%Y-%m-%dT%H:%M:%SZ'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Prometheus metrics
REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP Requests', ['endpoint'])
REQUEST_LATENCY = Histogram('http_request_duration_seconds', 'HTTP request latency')

@app.route('/health')
def health():
    start = time.time()
    REQUEST_COUNT.labels('/health').inc()
    
    response = jsonify({
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "service": "backend-api"
    })
    
    latency = time.time() - start
    REQUEST_LATENCY.observe(latency)
    logger.info(f"Health check completed - {latency:.4f}s")
    
    return response

@app.route('/metrics')
def metrics():
    REQUEST_COUNT.labels('/metrics').inc()
    logger.info("Metrics endpoint accessed")
    return generate_latest(REGISTRY), 200, {'Content-Type': 'text/plain'}

@app.route('/info')
def info():
    REQUEST_COUNT.labels('/info').inc()
    logger.info("Info endpoint accessed")
    return jsonify({
        "service": "backend-api",
        "version": "1.0.0",
        "endpoints": ["/health", "/metrics", "/info"]
    })

if __name__ == '__main__':
    logger.info("Backend API starting")
    app.run(host='0.0.0.0', port=5000)